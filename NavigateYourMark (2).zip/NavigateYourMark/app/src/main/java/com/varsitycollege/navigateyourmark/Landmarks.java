package com.varsitycollege.navigateyourmark;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import java.util.ArrayList;
import java.util.List;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class Landmarks extends AppCompatActivity {

    private ListView lstvLandmarks;
    private List<String> orderList;
    private ArrayAdapter<String> orderAdapter;
    private FirebaseDatabase database = FirebaseDatabase.getInstance();
    private DatabaseReference NavigateYourMark = database.getReference("Landmarks");
    //BottomNavigationView bottomNavView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_landmarks);
        orderList = new ArrayList<>();
        //bottomNavView.findViewById(R.id.bottom_navigator);
        //bottomNavView.setSelectedItemId(R.id.landmark);
        lstvLandmarks = findViewById(R.id.lstv_Landmarks);

        NavigateYourMark.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot pulledOrder : snapshot.getChildren()) {
                    Landmark landmark = pulledOrder.getValue(Landmark.class);
                    orderList.add(landmark.toString());
                }
                orderAdapter = new ArrayAdapter<String>(Landmarks.this,
                        android.R.layout.simple_list_item_1, orderList);
                lstvLandmarks.setAdapter(orderAdapter);
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error){
                Toast.makeText(Landmarks.this,
                        "Error Reading from Database", Toast.LENGTH_SHORT).show();
            }
        });
      /*  bottomNavView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener()
        {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item)
            {
                switch (item.getItemId())
                {
                    case R.id.home:
                        startActivity(new Intent(getApplicationContext(),MainMenu.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.landmark:
                        return true;
                    case R.id.mapsExplorer:
                        startActivity(new Intent(getApplicationContext(),MapsExplorer.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.personalAccount:
                        startActivity(new Intent(getApplicationContext(),Account.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.settings:
                        startActivity(new Intent(getApplicationContext(),Settings.class));
                        overridePendingTransition(0,0);
                        return true;
                }
                return false;
            }
        });*/

    }
}