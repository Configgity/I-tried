package com.varsitycollege.navigateyourmark;

public class SettingsDatabase {
    private String metric;
    private String miles;
    private String landmark;


    public SettingsDatabase(){

    }
    public SettingsDatabase(String metric,String miles, String landmark ){
        this.metric=metric;
        this.miles=miles;
        this.landmark=landmark;
    }

    public String getMetric(){return metric;}
    public void setMetric(String metric){this.metric = metric;}

    public String getMiles(){return miles;}
    public void setMiles(String miles){this.miles=miles;}

    public String getLandmark(){return landmark;}
    public void setLandmark(String landmark){this.landmark=landmark;}


    @Override
    public String toString(){
        return "Metric: " + metric + '\n';
    }
}
