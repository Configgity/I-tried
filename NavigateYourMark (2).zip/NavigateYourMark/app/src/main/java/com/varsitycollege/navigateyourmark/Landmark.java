package com.varsitycollege.navigateyourmark;

public class Landmark {
    public String Name;


    public Landmark() {

    }

    public Landmark(String Name) {
        this.Name = Name;
    }

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    @Override
    public String toString() {
        return "Landmark: " + Name + '\n';

    }
}