package com.varsitycollege.navigateyourmark;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Settings extends AppCompatActivity {

    BottomNavigationView bottomNavView;
    private FirebaseDatabase database = FirebaseDatabase.getInstance();
    private DatabaseReference NavigateYourMark = database.getReference("settings");
    private SettingsDatabase settingsDatabase;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        bottomNavView.findViewById(R.id.bottom_navigator);
        bottomNavView.setSelectedItemId(R.id.settings);

        bottomNavView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener()
        {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item)
            {
                switch (item.getItemId())
                {
                    case R.id.home:
                        startActivity(new Intent(getApplicationContext(),MainMenu.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.landmark:
                        startActivity(new Intent(getApplicationContext(),Landmarks.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.mapsExplorer:
                        startActivity(new Intent(getApplicationContext(),MapsExplorer.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.personalAccount:
                        startActivity(new Intent(getApplicationContext(),Account.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.settings:
                        return true;
                }

                return false;
            }
        });
    }
}