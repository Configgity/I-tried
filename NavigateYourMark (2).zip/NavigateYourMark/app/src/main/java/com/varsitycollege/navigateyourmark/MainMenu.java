package com.varsitycollege.navigateyourmark;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainMenu extends AppCompatActivity {

    private Button landmarks;
   // BottomNavigationView bottomNavView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_menu);
landmarks= findViewById(R.id.btn_nearbyLandmarks);
        landmarks.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                Intent intent = new Intent(MainMenu.this, Landmarks.class);
                startActivity(intent);
            }
        });
        /*bottomNavView.findViewById(R.id.bottom_navigator);
        bottomNavView.setSelectedItemId(R.id.home);

        bottomNavView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener()
        {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item)
            {
                switch (item.getItemId())
                {
                    case R.id.home:
                        return true;
                    case R.id.landmark:
                        startActivity(new Intent(getApplicationContext(),Landmarks.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.mapsExplorer:
                        startActivity(new Intent(getApplicationContext(),MapsExplorer.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.personalAccount:
                        startActivity(new Intent(getApplicationContext(),Account.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.settings:
                        startActivity(new Intent(getApplicationContext(),Settings.class));
                        overridePendingTransition(0,0);
                        return true;
                }

                return false;
            }
        });*/
    }
}