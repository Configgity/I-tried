package com.varsitycollege.navigateyourmark;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Transportation extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_transportation);
    }
}