package com.varsitycollege.navigateyourmark;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class Account extends AppCompatActivity {

    BottomNavigationView bottomNavView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account);

        bottomNavView.findViewById(R.id.bottom_navigator);
        bottomNavView.setSelectedItemId(R.id.personalAccount);

        bottomNavView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener()
        {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item)
            {
                switch (item.getItemId())
                {
                    case R.id.home:
                        startActivity(new Intent(getApplicationContext(),MainMenu.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.landmark:
                        startActivity(new Intent(getApplicationContext(),Landmarks.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.mapsExplorer:
                        startActivity(new Intent(getApplicationContext(),MapsExplorer.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.personalAccount:
                        return true;
                    case R.id.settings:
                        startActivity(new Intent(getApplicationContext(),Settings.class));
                        overridePendingTransition(0,0);
                        return true;
                }

                return false;
            }
        });
    }
}